# define COUNT 100
# define ADD(a,b)\
	 a+b \

int main() {
	int myCount = COUNT ;
	int d = ADD(3,4);
}
