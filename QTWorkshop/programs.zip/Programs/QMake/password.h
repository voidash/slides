#pragma once

#define USERNAME Admin
#define PASSWORD Admin

