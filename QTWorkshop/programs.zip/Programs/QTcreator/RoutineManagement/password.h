#ifndef PASSWORD_H
#define PASSWORD_H
    #define PASSWORD "yourpassword"
#endif // PASSWORD_H
